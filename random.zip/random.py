import random
def generate_arithmetic_sequence():
    start = random.randint(1, 10)
    step = random.randint(1, 5)
    length = 5
    sequence = [start + i * step for i in range(length)]
    missing_index = random.randint(1, length - 2)  # avoid hiding the first or last number
    correct_answer = sequence[missing_index]
    sequence[missing_index] = "?"
    return sequence, correct_answer


def play_game():
    print("Welcome to Number Detective!")
    print("Can you find the missing number in the sequence?\n")

    score = 0
    rounds = 3

    for i in range(rounds):
        sequence, correct_answer = generate_arithmetic_sequence()
        print(f"Round {i + 1}: {'  '.join(map(str, sequence))}")

        guess = input("Your guess: ").strip()

        if not guess.isdigit():
            print("⚠ Please enter a valid number.\n")
            continue

        if int(guess) == correct_answer:
            print("✅ Correct!\n")
            score += 1
        else:
            print(f"❌ Oops! The correct answer was {correct_answer}.\n")

    print(f"🎯 Game Over! You scored {score}/{rounds}.")


if '_name_' == "_main_":
    play_game()